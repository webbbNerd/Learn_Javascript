import "./styles.css";
import { useState, useRef, useEffect } from "react";
import axios from "axios";

export default function App() {
  const [data, setData] = useState([]);

  let apiUrl = "https://dummyjson.com/products";

  useEffect(() => {
    // fetch(apiUrl)
    //   .then((res) => res.json())
    //   .then((data) => console.log(data.products));

    async function run() {
      try {
        let res = await axios.get(apiUrl);
        setData(res.data.products);
      } catch (err) {
        console.log(err);
      }
    }
    run();
  }, []);
  return (
    <>
      <div>
        <table>
          <tr style={{ border: " 1px solid #000" }}>
            <th>Id</th>
            <th>Title</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Brand</th>
          </tr>
          {data
            .sort((a, b) => a.id - b.id)
            // .sort((a, b) =>
            //   a.brand > b.brand ? 1 : a.brand < b.brand ? -1 : 0
            // )
            .map((val, ind) => {
              return (
                <tr key={ind}>
                  <td>{val.id}</td>
                  <td>{val.title}</td>
                  <td>{val.price}</td>
                  <td>{val.stock}</td>
                  <td>{val.brand}</td>
                </tr>
              );
            })}
        </table>
      </div>
    </>
  );
}
